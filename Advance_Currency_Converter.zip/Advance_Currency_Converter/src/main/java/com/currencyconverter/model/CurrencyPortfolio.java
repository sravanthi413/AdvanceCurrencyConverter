package com.currencyconverter.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CurrencyPortfolio {
    private Map<String, Double> userPortfolio;

    public CurrencyPortfolio() {
        this.userPortfolio = new HashMap<>();
    }

    public void addCurrency(String currencyCode, double amount) {
        userPortfolio.put(currencyCode.toUpperCase(), amount);
    }

    public Double getCurrencyAmount(String currencyCode) {
        return userPortfolio.get(currencyCode.toUpperCase());
    }

    public void updateCurrencyAmount(String currencyCode, double newAmount) {
        userPortfolio.put(currencyCode.toUpperCase(), newAmount);
    }

    public void deleteCurrency(String currencyCode) {
        userPortfolio.remove(currencyCode.toUpperCase());
    }

    public List<String> getAllCurrencies() {
        return new ArrayList<>(userPortfolio.keySet());
    }

    public Map<String, Double> getAllCurrencyAmounts() {
        return new HashMap<>(userPortfolio);
    }

    // Other methods as needed
}