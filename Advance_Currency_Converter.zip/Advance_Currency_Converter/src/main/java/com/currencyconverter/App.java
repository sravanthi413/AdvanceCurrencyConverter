package com.currencyconverter;

import com.currencyconverter.model.Currency;
import com.currencyconverter.service.CurrencyService;
import com.currencyconverter.service.ExternalIntegrationManager;
import com.currencyconverter.util.DatabaseManager;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class App {
    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager();
        CurrencyService currencyService = new CurrencyService(dbManager);
        ExternalIntegrationManager integrationManager = new ExternalIntegrationManager();

        // Load initial exchange rates
        Map<String, Double> rates = integrationManager.fetchExchangeRates();
        System.out.println("Fetched exchange rates: " + rates);
        for (Map.Entry<String, Double> entry : rates.entrySet()) {
            currencyService.addCurrency(new Currency(entry.getKey(), entry.getKey(), entry.getValue()));
        }

        // Create a thread pool for concurrent currency conversions
        ExecutorService executor = Executors.newFixedThreadPool(5);

        // Start a thread for real-time updates
        // Thread realTimeUpdateThread = new Thread(() -> {
        //     while (!Thread.currentThread().isInterrupted()) {
        //         try {
        //             Map<String, Double> updatedRates = integrationManager.fetchExchangeRates();
        //             for (Map.Entry<String, Double> entry : updatedRates.entrySet()) {
        //                 currencyService.updateExchangeRate(entry.getKey(), entry.getValue());
        //             }
        //             // Display the current exchange rates
        //             System.out.println("\nCurrent exchange rates:");
        //             updatedRates.forEach((key, value) -> System.out.println(key + ": " + value));
        //             // Sleep for 10 seconds before the next update
        //             Thread.sleep(1000000);
        //         } catch (InterruptedException e) {
        //             Thread.currentThread().interrupt();
        //         }
        //     }
        // });
        // realTimeUpdateThread.start();

        Scanner scanner = new Scanner(System.in);

        System.out.println();
        while (true) {
            System.out.println("Enter source currency code:");
            String fromCode = scanner.nextLine().trim().toUpperCase();
            System.out.println("Enter target currency code:");
            String toCode = scanner.nextLine().trim().toUpperCase();
            System.out.println("Enter amount to convert:");
            double amount = Double.parseDouble(scanner.nextLine());

            // Submit currency conversion task to the thread pool
            executor.submit(() -> {
                try {
                    double convertedAmount = currencyService.convert(fromCode, toCode, amount);
                    System.out.println("Converted amount: " + convertedAmount);
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            });

            System.out.println("Do you want to perform another conversion? (yes/no)");
            String response = scanner.nextLine();
            if (!response.equalsIgnoreCase("yes")) {
                break;
            }
        }

        // Shutdown the thread pool after conversions are done
        // executor.shutdown();

        // // Interrupt the real-time update thread and wait for it to finish
        // realTimeUpdateThread.interrupt();
        // try {
        //     realTimeUpdateThread.join();
        // } catch (InterruptedException e) {
        //     Thread.currentThread().interrupt();
        // }

        // Filter currencies based on exchange rate thresholds
        double minRate = 0.8;
        double maxRate = 1.2;
        List<Currency> filteredCurrencies = currencyService.filterCurrenciesByExchangeRate(minRate, maxRate);

        // Display filtered currencies
        System.out.println("Currencies with exchange rate between " + minRate + " and " + maxRate + ":");
        for (Currency currency : filteredCurrencies) {
            System.out.println(currency.getCode() + ": " + currency.getExchangeRate());
        }

        scanner.close();
    }
}
