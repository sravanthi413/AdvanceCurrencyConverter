package com.currencyconverter.util;

import com.currencyconverter.model.Currency;
import com.currencyconverter.model.CurrencyPortfolio;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class DatabaseManager {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/advCurrency";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "9866107075"; // Replace with your actual password

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
    }

    public void saveCurrency(Currency currency) {
        String query = "INSERT INTO Currencies (code, name, exchangeRate) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), exchangeRate=VALUES(exchangeRate)";
        try (Connection connection = getConnection(); PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, currency.getCode());
            ps.setString(2, currency.getName());
            ps.setDouble(3, currency.getExchangeRate());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<String, Currency> getAllCurrencies() {
        Map<String, Currency> currencies = new HashMap<>();
        String query = "SELECT * FROM Currencies";
        try (Connection connection = getConnection(); Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String code = rs.getString("code");
                String name = rs.getString("name");
                double exchangeRate = rs.getDouble("exchangeRate");
                currencies.put(code, new Currency(code, name, exchangeRate));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return currencies;
    }

    public void saveUserPortfolio(String userId, CurrencyPortfolio portfolio) {
        String deleteQuery = "DELETE FROM UserPortfolios WHERE userId = ?";
        String insertQuery = "INSERT INTO UserPortfolios (userId, currencyCode, amount) VALUES (?, ?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement deletePs = connection.prepareStatement(deleteQuery);
             PreparedStatement insertPs = connection.prepareStatement(insertQuery)) {

            // Clear existing portfolio for the user
            deletePs.setString(1, userId);
            deletePs.executeUpdate();

            // Insert new portfolio data
            for (Map.Entry<String, Double> entry : portfolio.getAllCurrencyAmounts().entrySet()) {
                insertPs.setString(1, userId);
                insertPs.setString(2, entry.getKey());
                insertPs.setDouble(3, entry.getValue());
                insertPs.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public CurrencyPortfolio getUserPortfolio(String userId) {
        CurrencyPortfolio portfolio = new CurrencyPortfolio();
        String query = "SELECT * FROM UserPortfolios WHERE userId = ?";
        try (Connection connection = getConnection(); PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String currencyCode = rs.getString("currencyCode");
                    double amount = rs.getDouble("amount");
                    portfolio.addCurrency(currencyCode, amount);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return portfolio;
    }

    // Add other necessary CRUD methods
}
