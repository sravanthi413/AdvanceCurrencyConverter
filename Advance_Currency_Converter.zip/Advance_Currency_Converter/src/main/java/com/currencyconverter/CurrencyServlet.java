package com.currencyconverter;

import com.currencyconverter.service.CurrencyService;
import com.currencyconverter.model.Currency;
import com.currencyconverter.util.DatabaseManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/currency")
public class CurrencyServlet extends HttpServlet {

    private CurrencyService currencyService;
    private static final Logger LOGGER = Logger.getLogger(CurrencyServlet.class.getName());

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            DatabaseManager dbManager = new DatabaseManager();
            currencyService = new CurrencyService(dbManager);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error initializing CurrencyService", e);
            throw new ServletException("Failed to initialize CurrencyService", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Currency> currencies = currencyService.filterCurrenciesByExchangeRate(0, Double.MAX_VALUE); // Example usage
        request.setAttribute("currencies", currencies);
        request.getRequestDispatcher("currency.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        LOGGER.info("Action: " + action);
        String errorMessage = null;

        try {
            if (currencyService == null) {
                throw new ServletException("currencyService is null in doPost method");
            }

            if ("add".equals(action)) {
                String code = request.getParameter("code");
                String name = request.getParameter("name");
                String rateStr = request.getParameter("rate");

                LOGGER.info("Parameters received - code: " + code + ", name: " + name + ", rate: " + rateStr);

                if (code != null && !code.isEmpty() && name != null && !name.isEmpty() && rateStr != null && !rateStr.isEmpty()) {
                    try {
                        double rate = Double.parseDouble(rateStr);
                        Currency currency = new Currency(code, name, rate);
                        currencyService.addCurrency(currency);
                        LOGGER.info("Currency added successfully");
                    } catch (NumberFormatException e) {
                        LOGGER.log(Level.SEVERE, "Invalid exchange rate format: " + rateStr, e);
                        errorMessage = "Invalid exchange rate format.";
                    }
                } else {
                    errorMessage = "Missing required parameters.";
                }

            } else if ("update".equals(action)) {
                String code = request.getParameter("code");
                String rateStr = request.getParameter("rate");

                LOGGER.info("Parameters received for update - code: " + code + ", rate: " + rateStr);

                if (code != null && !code.isEmpty() && rateStr != null && !rateStr.isEmpty()) {
                    try {
                        double rate = Double.parseDouble(rateStr);
                        currencyService.updateExchangeRate(code, rate);
                        LOGGER.info("Exchange rate updated successfully");
                    } catch (NumberFormatException e) {
                        LOGGER.log(Level.SEVERE, "Invalid exchange rate format: " + rateStr, e);
                        errorMessage = "Invalid exchange rate format.";
                    }
                } else {
                    errorMessage = "Missing required parameters.";
                }
            }

            if (errorMessage != null) {
                request.setAttribute("error", errorMessage);
                request.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(request, response);
            } else {
                response.sendRedirect("currency");
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in doPost method", e);
            request.setAttribute("error", "Failed to process request");
            request.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(request, response);
        }
    }
}
