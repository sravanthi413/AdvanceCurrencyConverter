package com.currencyconverter.service;

import com.currencyconverter.model.Currency;
import com.currencyconverter.util.DatabaseManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class CurrencyService {
    private final Map<String, Currency> currencies;
    private final DatabaseManager dbManager;
    private final List<String> conversionHistory;

    public CurrencyService(DatabaseManager dbManager) {
        this.dbManager = dbManager;
        this.currencies = new ConcurrentHashMap<>(dbManager.getAllCurrencies());
        this.conversionHistory = new ArrayList<>();
    }

    public synchronized void addCurrency(Currency currency) {
        currencies.put(currency.getCode().toUpperCase(), currency);
        dbManager.saveCurrency(currency);
    }

    public synchronized Currency getCurrency(String code) {
        return currencies.get(code.toUpperCase());
    }

    public synchronized double convert(String fromCode, String toCode, double amount) {
        Currency fromCurrency = currencies.get(fromCode.toUpperCase());
        Currency toCurrency = currencies.get(toCode.toUpperCase());

        if (fromCurrency == null) {
            throw new IllegalArgumentException("Invalid source currency code: " + fromCode);
        }
        if (toCurrency == null) {
            throw new IllegalArgumentException("Invalid target currency code: " + toCode);
        }

        double conversionRate = toCurrency.getExchangeRate() / fromCurrency.getExchangeRate();
        double convertedAmount = amount * conversionRate;

        // Add to conversion history
        String entry = String.format("%s to %s - Amount: %.2f, Converted: %.2f", fromCode, toCode, amount, convertedAmount);
        addToConversionHistory(entry);

        return convertedAmount;
    }

    public synchronized void updateExchangeRate(String code, double newRate) {
        Currency currency = currencies.get(code.toUpperCase());
        if (currency != null) {
            currency.setExchangeRate(newRate);
            dbManager.saveCurrency(currency);
        }
    }

    public synchronized List<Currency> filterCurrenciesByExchangeRate(double minRate, double maxRate) {
        return currencies.values().stream()
                .filter(currency -> currency.getExchangeRate() >= minRate && currency.getExchangeRate() <= maxRate)
                .collect(Collectors.toList());
    }

    public synchronized void fetchCurrentExchangeRates() {
        // Simulate fetching rates from an API or actual exchange rate provider
        Random random = new Random();
        for (Currency currency : currencies.values()) {
            double newRate = currency.getExchangeRate() * (1 + (random.nextDouble() * 0.1 - 0.05)); // Random fluctuation
            currency.setExchangeRate(newRate);
            dbManager.saveCurrency(currency);
        }
    }

    public List<String> getConversionHistory() {
        return new ArrayList<>(conversionHistory);
    }

    public void addToConversionHistory(String entry) {
        conversionHistory.add(entry);
    }

    public Map<String, Currency> getAllCurrencies() {
        return currencies;
    }
}