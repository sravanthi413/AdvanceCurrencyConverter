package com.currencyconverter.service;

import com.currencyconverter.model.Currency;
import com.currencyconverter.util.LoggingUtil;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class HistoricalExchangeRateService {
    private static final String API_URL = "https://api.exchangeratesapi.io/history?start_at=%s&end_at=%s&base=%s&symbols=%s";

    public Map<LocalDate, Double> getHistoricalRates(String baseCurrency, String targetCurrency, LocalDate startDate, LocalDate endDate) {
        Map<LocalDate, Double> historicalRates = new HashMap<>();
        try {
            String formattedUrl = String.format(API_URL, startDate.toString(), endDate.toString(), baseCurrency, targetCurrency);
            URL url = new URL(formattedUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer content = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();

            JSONObject json = new JSONObject(content.toString());
            JSONObject ratesJson = json.getJSONObject("rates");

            for (String date : ratesJson.keySet()) {
                JSONObject dailyRates = ratesJson.getJSONObject(date);
                double rate = dailyRates.getDouble(targetCurrency);
                historicalRates.put(LocalDate.parse(date), rate);
            }
        } catch (Exception e) {
            LoggingUtil.logError("Error fetching historical exchange rates", e);
        }
        return historicalRates;
    }
}
