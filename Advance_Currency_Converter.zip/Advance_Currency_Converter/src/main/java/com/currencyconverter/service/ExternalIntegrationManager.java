package com.currencyconverter.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

public class ExternalIntegrationManager {
    private static final String API_URL = "https://api.exchangerate-api.com/v4/latest/USD"; // Corrected URL

    public Map<String, Double> fetchExchangeRates() {
        Map<String, Double> rates = new HashMap<>();
        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();

            JSONObject json = new JSONObject(content.toString());
            JSONObject ratesJson = json.getJSONObject("rates");

            for (String key : ratesJson.keySet()) {
                rates.put(key, ratesJson.getDouble(key));
            }

            // Print fetched exchange rates for debugging
            System.out.println("Fetched exchange rates: " + rates);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rates;
    }
}
