package com.currencyconverter.service;

import com.currencyconverter.model.Currency;
import com.currencyconverter.util.LoggingUtil;
import java.util.HashMap;
import java.util.Map;

public class SmartConversionEngine {
    private CurrencyService currencyService;
    private Map<String, Double> userConversionPatterns;

    public SmartConversionEngine(CurrencyService currencyService) {
        this.currencyService = currencyService;
        this.userConversionPatterns = new HashMap<>();
    }

    public void analyzeUserPattern(String userId, String fromCurrencyCode, String toCurrencyCode, double amount) {
        String key = generateKey(userId, fromCurrencyCode, toCurrencyCode);
        userConversionPatterns.put(key, userConversionPatterns.getOrDefault(key, 0.0) + amount);
    }

    public double suggestOptimalConversion(String userId, String fromCurrencyCode, String toCurrencyCode) {
        String key = generateKey(userId, fromCurrencyCode, toCurrencyCode);
        if (userConversionPatterns.containsKey(key)) {
            double totalConverted = userConversionPatterns.get(key);
            double averageConversion = totalConverted / userConversionPatterns.size();
            LoggingUtil.logInfo("Suggested conversion amount for " + key + ": " + averageConversion);
            return averageConversion;
        }
        return 0;
    }

    private String generateKey(String userId, String fromCurrencyCode, String toCurrencyCode) {
        return userId + "_" + fromCurrencyCode + "_" + toCurrencyCode;
    }
}

