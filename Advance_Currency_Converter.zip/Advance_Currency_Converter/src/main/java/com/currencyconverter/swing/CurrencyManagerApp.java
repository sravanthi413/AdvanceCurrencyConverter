package com.currencyconverter.swing;

import com.currencyconverter.model.Currency;
import com.currencyconverter.service.CurrencyService;
import com.currencyconverter.util.DatabaseManager;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class CurrencyManagerApp extends JFrame {

    private CurrencyService currencyService;

    // Components for Add Currency panel
    private JTextField addCodeField;
    private JTextField addNameField;
    private JTextField addRateField;

    // Components for Convert Currency panel
    private JTextField convertFromCodeField;
    private JTextField convertToCodeField;
    private JTextField convertAmountField;

    private JTextArea historyTextArea;

    public CurrencyManagerApp(CurrencyService currencyService) {
        this.currencyService = currencyService;

        setTitle("Currency Converter");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initComponents();
    }

    private void initComponents() {
        JPanel buttonPanel = new JPanel();
        JButton fetchRatesButton = new JButton("Fetch Exchange Rates");

        // Fetch Exchange Rates button action listener
        fetchRatesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fetchCurrentExchangeRates();
            }
        });

        // Apply some styling to the Fetch Rates button
        fetchRatesButton.setBackground(new Color(51, 153, 255)); // Light blue background
        fetchRatesButton.setForeground(Color.WHITE); // White text
        fetchRatesButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20)); // Padding inside the button
        fetchRatesButton.setFocusPainted(false); // Remove focus border

        // Add buttons to button panel
        buttonPanel.add(fetchRatesButton);  // Add fetch rates button to the button panel
        buttonPanel.setBorder(new EmptyBorder(10, 20, 20, 20)); // Adjust padding

        // Create a tabbed pane and add panels
        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel addCurrencyPanel = createAddCurrencyPanel();
        tabbedPane.addTab("Add Currency", addCurrencyPanel);

        JPanel convertCurrencyPanel = createConvertCurrencyPanel();
        tabbedPane.addTab("Convert Currency", convertCurrencyPanel);

        JPanel historyPanel = createHistoryPanel();
        tabbedPane.addTab("Conversion History", historyPanel);

        // Add components to the content pane
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(buttonPanel, BorderLayout.WEST); // Align button panel to the left
        getContentPane().add(tabbedPane, BorderLayout.CENTER);

        // Initialize history
        refreshConversionHistory();
    }

    private JPanel createAddCurrencyPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(createStyledBorder()); // Add styled border

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel codeLabel = new JLabel("Currency Code:");
        panel.add(codeLabel, gbc);

        addCodeField = new JTextField(10);
        gbc.gridx = 1;
        panel.add(addCodeField, gbc);

        JLabel nameLabel = new JLabel("Currency Name:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(nameLabel, gbc);

        addNameField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(addNameField, gbc);

        JLabel rateLabel = new JLabel("Exchange Rate:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(rateLabel, gbc);

        addRateField = new JTextField(10);
        gbc.gridx = 1;
        panel.add(addRateField, gbc);

        JButton addButton = new JButton("Add Currency");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(20, 10, 10, 10); // Larger bottom padding
        panel.add(addButton, gbc);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addCurrency();
            }
        });

        // Apply some styling to the button
        addButton.setBackground(new Color(51, 153, 255)); // Light blue background
        addButton.setForeground(Color.WHITE); // White text
        addButton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding inside the button
        addButton.setFocusPainted(false); // Remove focus border

        return panel;
    }

    private JPanel createConvertCurrencyPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(createStyledBorder()); // Add styled border

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel fromLabel = new JLabel("From Currency Code:");
        panel.add(fromLabel, gbc);

        convertFromCodeField = new JTextField(10);
        gbc.gridx = 1;
        panel.add(convertFromCodeField, gbc);

        JLabel toLabel = new JLabel("To Currency Code:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(toLabel, gbc);

        convertToCodeField = new JTextField(10);
        gbc.gridx = 1;
        panel.add(convertToCodeField, gbc);

        JLabel amountLabel = new JLabel("Amount:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(amountLabel, gbc);

        convertAmountField = new JTextField(10);
        gbc.gridx = 1;
        panel.add(convertAmountField, gbc);

        JButton convertButton = new JButton("Convert");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(20, 10, 10, 10); // Larger bottom padding
        panel.add(convertButton, gbc);

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertCurrency();
            }
        });

        // Apply some styling to the button
        convertButton.setBackground(new Color(255, 102, 0)); // Orange background
        convertButton.setForeground(Color.WHITE); // White text
        convertButton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding inside the button
        convertButton.setFocusPainted(false); // Remove focus border

        return panel;
    }

    private JPanel createHistoryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(createStyledBorder()); // Add styled border

        historyTextArea = new JTextArea(20, 40);
        historyTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(historyTextArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh History");
        panel.add(refreshButton, BorderLayout.SOUTH);

        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshConversionHistory();
            }
        });

        // Apply some styling to the refresh button
        refreshButton.setBackground(new Color(0, 153, 0)); // Green background
        refreshButton.setForeground(Color.WHITE); // White text
        refreshButton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding inside the button
        refreshButton.setFocusPainted(false); // Remove focus border

        return panel;
    }

    private Border createStyledBorder() {
        // Create a compound border with padding and a line border with rounded corners and shadow
        Border line = new LineBorder(Color.LIGHT_GRAY);
        Border empty = new EmptyBorder(10, 10, 10, 10);
        return new CompoundBorder(line, empty);
    }

    private void addCurrency() {
        try {
            String code = addCodeField.getText().trim();
            String name = addNameField.getText().trim();
            double rate = Double.parseDouble(addRateField.getText().trim());

            if (currencyService.getCurrency(code) != null) {
                showError("Currency with code " + code + " already exists.");
                return;
            }

            Currency currency = new Currency(code, name, rate);
            currencyService.addCurrency(currency);

            JOptionPane.showMessageDialog(this,
                    "Currency added successfully",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            clearAddCurrencyFields();
        } catch (NumberFormatException ex) {
            showError("Invalid exchange rate format.");
        }
    }

    private void convertCurrency() {
        try {
            String fromCode = convertFromCodeField.getText().trim();
            String toCode = convertToCodeField.getText().trim();
            double amount = Double.parseDouble(convertAmountField.getText().trim());

            double convertedAmount = currencyService.convert(fromCode, toCode, amount);

            JOptionPane.showMessageDialog(this,
                    "Converted amount: " + convertedAmount,
                    "Conversion Result",
                    JOptionPane.INFORMATION_MESSAGE);

            String conversionEntry = String.format("%s: %s to %s - Amount: %.2f, Converted: %.2f",
                    LocalDate.now(), fromCode, toCode, amount, convertedAmount);
            currencyService.addToConversionHistory(conversionEntry);
            clearConvertCurrencyFields();
        } catch (NumberFormatException ex) {
            showError("Invalid amount or exchange rate format.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private void fetchCurrentExchangeRates() {
        StringBuilder ratesInfo = new StringBuilder("Current Exchange Rates:\n");

        // Fetch current exchange rates for all currencies
        for (Map.Entry<String, Currency> entry : currencyService.getAllCurrencies().entrySet()) {
            Currency currency = entry.getValue();
            ratesInfo.append(currency.getCode()).append(": ").append(currency.getExchangeRate()).append("\n");
        }

        JOptionPane.showMessageDialog(this,
                ratesInfo.toString(),
                "Current Exchange Rates",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void refreshConversionHistory() {
        historyTextArea.setText("");
        List<String> conversionHistory = currencyService.getConversionHistory();
        for (String entry : conversionHistory) {
            historyTextArea.append(entry + "\n");
        }
    }

    private void clearAddCurrencyFields() {
        addCodeField.setText("");
        addNameField.setText("");
        addRateField.setText("");
    }

    private void clearConvertCurrencyFields() {
        convertFromCodeField.setText("");
        convertToCodeField.setText("");
        convertAmountField.setText("");
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this,
                message,
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            // Set Nimbus look and feel for a modern appearance
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                DatabaseManager dbManager = new DatabaseManager(); // Replace with actual implementation
                CurrencyService currencyService = new CurrencyService(dbManager);
                CurrencyManagerApp app = new CurrencyManagerApp(currencyService);
                app.setVisible(true);
            }
        });
    }
}